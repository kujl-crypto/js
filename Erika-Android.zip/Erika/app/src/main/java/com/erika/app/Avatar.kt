package com.erika.app

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.platform.LocalContext
import kotlin.math.*

/** Размеры вырезанной фигуры в «исходных» пикселях (все координаты ниже — в них). */
private const val FW = 414f
private const val FH = 1147f
private const val COLS = 30
private const val ROWS = 84
private const val LOOP = 12f // секунд. Все гармоники кратны, поэтому первый и последний кадр совпадают.

private fun smooth(v: Float): Float {
    val t = v.coerceIn(0f, 1f); return t * t * (3f - 2f * t)
}
private fun bump(y: Float, c: Float, w: Float) = smooth(1f - abs(y - c) / w)

/** Мягкое пятно, внутри которого волосы/ткань качаются как маятник от точки крепления. */
private class Blob(
    val cx: Float, val cy: Float, val rx: Float, val ry: Float,
    val attachY: Float, val len: Float,
    val ax: Float, val ay: Float,
    val n: Int, val phase: Float, val k: Float,
    val guardSide: Int = 0, val guardX: Float = 0f, val guardSlope: Float = 0f
) { var a = 0f }

private class Eye(val cx: Float, val cy: Float, val rx: Float, val ry: Float, val rot: Float)

class Anim {
    private val w0 = (2.0 * PI / LOOP).toFloat()
    private var headBias = 0f
    private var talk = 0f
    // параметры текущего кадра
    private var hipShift = 0f; private var upperShift = 0f; private var lean = 0f
    private var hipRock = 0f; private var headAng = 0f; private var headBob = 0f
    private var breathLift = 0f; private var breathWide = 0f
    var blink = 0f; private set
    private var nextBlink = 2.2f; private var blinkStart = -10f; private var doubleBlink = false

    private val blobs = listOf(
        // длинные волосы/плащ слева (не трогаем левую ногу: guard)
        Blob(70f, 500f, 120f, 330f, 200f, 560f, 8.5f, 1.5f, 2, 0.0f, 1.8f, -1, 105f, 0.25f),
        // длинные волосы справа сверху
        Blob(325f, 280f, 62f, 170f, 140f, 300f, 5.5f, 1.0f, 2, 1.0f, 1.6f),
        // правая часть куртки
        Blob(315f, 420f, 75f, 95f, 300f, 200f, 3.0f, 0.8f, 3, 0.4f, 1.2f),
        // нижняя правая прядь (не трогаем правую ногу)
        Blob(350f, 610f, 26f, 125f, 500f, 200f, 6.0f, 1.0f, 2, 1.6f, 1.4f, 1, 330f, 0f),
        // подол юбки
        Blob(207f, 470f, 185f, 42f, 430f, 60f, 2.2f, 0.8f, 3, 2.0f, 1.0f),
        // «ушки» из волос
        Blob(122f, 85f, 30f, 55f, 40f, 90f, 3.0f, 0.5f, 2, 0.3f, 1.2f),
        Blob(268f, 80f, 38f, 48f, 35f, 80f, 3.0f, 0.6f, 2, 0.9f, 1.2f),
        // пряди у лица
        Blob(148f, 170f, 30f, 55f, 120f, 100f, 2.6f, 0.5f, 3, 0.7f, 1.0f),
        Blob(265f, 165f, 32f, 55f, 120f, 100f, 2.6f, 0.5f, 3, 1.4f, 1.0f),
        // кисти и пальцы: крошечные расслабленные движения
        Blob(55f, 525f, 24f, 26f, 505f, 40f, 1.8f, 1.2f, 5, 0.2f, 1.5f),
        Blob(343f, 531f, 24f, 24f, 505f, 40f, 1.8f, 1.2f, 5, 1.1f, 1.5f)
    )
    private val eyes = listOf(Eye(174f, 111f, 15f, 9.5f, -7f), Eye(220.5f, 96f, 14.5f, 9.5f, -11f))

    fun update(t: Float, dt: Float, status: Status) {
        val th = w0 * t
        hipShift = 5.5f * sin(th)
        upperShift = -3.0f * sin(th - 0.15f)
        lean = 0.014f * sin(th - 0.5f)
        hipRock = 1.6f * sin(th + 0.2f)
        val breath = 0.5f + 0.5f * sin(3f * th - 1.0f)
        breathLift = 1.8f * breath; breathWide = 0.004f * breath
        // наклон головы следует за телом + реакция на состояние
        val target = when (status) { Status.LISTENING -> 0.04f; Status.THINKING -> -0.035f; else -> 0f }
        headBias += (target - headBias) * min(1f, dt * 3f)
        talk += ((if (status == Status.SPEAKING) 1f else 0f) - talk) * min(1f, dt * 3f)
        headAng = 0.035f * sin(th - 0.9f) + headBias + talk * 0.012f * sin(5f * th)
        headBob = -0.6f * breath + talk * 0.5f * sin(5f * th + 1f)
        for (b in blobs) b.a = b.n * th - b.phase
        updateBlink(t)
    }

    private fun updateBlink(t: Float) {
        if (t > nextBlink) {
            blinkStart = t
            doubleBlink = Random.nextFloat() < 0.2f
            nextBlink = t + 2.5f + Random.nextFloat() * 3.5f
        }
        val e = t - blinkStart
        blink = when {
            e < 0f || e > 0.32f -> 0f
            e < 0.07f -> smooth(e / 0.07f)
            e < 0.10f -> 1f
            e < 0.20f -> 1f - smooth((e - 0.10f) / 0.10f)
            doubleBlink && e < 0.27f -> smooth((e - 0.20f) / 0.035f).coerceAtMost(1f) * 0.9f
            doubleBlink -> 0.9f * (1f - smooth((e - 0.27f) / 0.05f))
            else -> 0f
        }
    }

    /** Смещение точки (x,y) исходной картинки в пикселях исходной картинки. */
    fun disp(x: Float, y: Float, o: FloatArray) {
        var dx = 0f; var dy = 0f
        // ноги/бёдра: ступни неподвижны, вес переносится в бёдра
        val legW = smooth((930f - y) / 490f)
        dx += hipShift * legW
        dy += hipRock * ((x - 207f) / 120f).coerceIn(-1.2f, 1.2f) * smooth((600f - y) / 160f)
        if (y < 440f) dx += lean * (440f - y)
        dx += upperShift * smooth((440f - y) / 250f)
        // дыхание: плечи и грудь
        val cw = bump(y, 225f, 55f)
        dy -= breathLift * cw
        dx += (x - 207f) * breathWide * cw
        // голова вращается вокруг шеи
        val hw = smooth((205f - y) / 65f)
        if (hw > 0f) {
            dx += hw * (-headAng * (y - 150f))
            dy += hw * (headAng * (x - 205f) + headBob)
        }
        // вторичное движение
        for (b in blobs) {
            val nx = (x - b.cx) / b.rx; val ny = (y - b.cy) / b.ry
            val r2 = nx * nx + ny * ny
            if (r2 >= 1f) continue
            var w = smooth((1f - sqrt(r2)) / 0.5f)
            if (b.guardSide != 0 && y > 440f) {
                val gx = if (b.guardSide < 0) min(135f, b.guardX + (y - 520f).coerceAtLeast(0f) * b.guardSlope) else b.guardX
                val g = if (b.guardSide < 0) smooth((gx - x) / 16f) else smooth((x - gx) / 16f)
                val ramp = smooth((y - 440f) / 30f)
                w *= (1f - ramp) + ramp * g
            }
            if (w <= 0f) continue
            val q = ((y - b.attachY) / b.len).coerceIn(0f, 1.3f)
            val ph = b.a - b.k * q
            dx += b.ax * w * q * sin(ph)
            dy += b.ay * w * q * cos(ph)
        }
        o[0] = dx; o[1] = dy
    }

    /** Рисует веки при моргании. s — масштаб, ox/oy — смещение фигуры на экране. */
    fun drawEyes(c: android.graphics.Canvas, s: Float, ox: Float, oy: Float, lid: Paint, lash: Paint) {
        if (blink < 0.02f) return
        val tmp = FloatArray(2)
        val p = Path(); val oval = RectF()
        for (e in eyes) {
            disp(e.cx, e.cy, tmp)
            val ex = ox + (e.cx + tmp[0]) * s; val ey = oy + (e.cy + tmp[1]) * s
            val rx = e.rx * s; val ry = e.ry * s
            c.save()
            c.translate(ex, ey)
            c.rotate(e.rot + Math.toDegrees(headAng.toDouble()).toFloat())
            p.reset(); oval.set(-rx, -ry, rx, ry); p.addOval(oval, Path.Direction.CW)
            c.clipPath(p)
            val lidY = -ry + (2f * ry * 0.95f) * blink       // веко опускается сверху
            c.drawRect(-rx, -ry, rx, lidY, lid)
            lash.alpha = (255 * min(1f, blink * 1.4f)).toInt()
            p.reset()
            p.moveTo(-rx * 1.0f, lidY - ry * 0.10f)
            p.quadTo(0f, lidY + ry * 0.50f * blink, rx * 1.0f, lidY - ry * 0.18f)
            c.drawPath(p, lash)
            c.restore()
        }
    }

    private object Random { fun nextFloat() = kotlin.random.Random.nextFloat() }
}

@Composable
fun ErikaStage(status: Status, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val bmp = remember {
        val o = BitmapFactory.Options().apply { inScaled = false }
        BitmapFactory.decodeResource(ctx.resources, R.drawable.erika, o)
    }
    val anim = remember { Anim() }
    val verts = remember { FloatArray((COLS + 1) * (ROWS + 1) * 2) }
    val paint = remember { Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG) }
    val lid = remember { Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFC4C3DB.toInt() } }
    val lash = remember { Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF34324E.toInt(); style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND } }
    val st = rememberUpdatedState(status)
    var tick by remember { mutableLongStateOf(0L) }

    LaunchedEffect(Unit) {
        var start = -1L; var last = 0L
        while (true) {
            val now = withFrameNanos { it }
            if (start < 0) { start = now; last = now }
            val dtN = now - last
            if (dtN < 30_000_000L) continue          // ~30 кадров/с: плавно и экономно
            anim.update((now - start) / 1e9f, dtN / 1e9f, st.value)
            last = now
            tick = now
        }
    }

    Canvas(modifier) {
        tick // подписка на перерисовку
        drawStage(bmp, anim, verts, paint, lid, lash)
    }
}

private fun DrawScope.drawStage(bmp: Bitmap, anim: Anim, verts: FloatArray, paint: Paint, lid: Paint, lash: Paint) {
    val w = size.width; val h = size.height
    drawRect(Brush.verticalGradient(listOf(Color(0xFF1C1E38), Color(0xFF0F1120), Color(0xFF171834))))
    val figH = h * 0.66f
    val s = figH / FH
    val ox = (w - FW * s) / 2f
    val oy = h * 0.19f
    // мягкое свечение за ней и тень на полу
    drawCircle(Brush.radialGradient(listOf(Color(0x555B63FF), Color.Transparent), Offset(w / 2f, oy + figH * 0.45f), w * 0.95f),
        radius = w * 0.95f, center = Offset(w / 2f, oy + figH * 0.45f))
    val floorY = oy + 1139f * s
    scale(1f, 0.12f, pivot = Offset(ox + 280f * s, floorY)) {
        drawCircle(Brush.radialGradient(listOf(Color(0xB0000000), Color.Transparent), Offset(ox + 280f * s, floorY), 230f * s),
            radius = 230f * s, center = Offset(ox + 280f * s, floorY))
    }

    val d = FloatArray(2)
    var i = 0
    for (r in 0..ROWS) {
        val y = FH * r / ROWS
        for (c in 0..COLS) {
            val x = FW * c / COLS
            anim.disp(x, y, d)
            verts[i++] = ox + (x + d[0]) * s
            verts[i++] = oy + (y + d[1]) * s
        }
    }
    drawIntoCanvas {
        val nc = it.nativeCanvas
        nc.drawBitmapMesh(bmp, COLS, ROWS, verts, 0, null, 0, paint)
        lash.strokeWidth = 1.9f * s * 1.6f
        anim.drawEyes(nc, s, ox, oy, lid, lash)
    }
}
