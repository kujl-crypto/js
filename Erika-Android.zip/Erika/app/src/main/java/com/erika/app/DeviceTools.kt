package com.erika.app

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.provider.AlarmClock
import android.provider.Settings
import android.view.KeyEvent
import kotlinx.coroutines.delay
import org.json.JSONArray
import org.json.JSONObject

class DeviceTools(context: Context, private val store: Store) {
    private val ctx = context.applicationContext

    private fun start(i: Intent) = ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))

    private fun d(name: String, desc: String, vararg p: Triple<String, String, String>): JSONObject {
        val props = JSONObject()
        p.forEach { props.put(it.first, JSONObject().put("type", it.second).put("description", it.third)) }
        val req = JSONArray(p.filter { !it.third.startsWith("(опц)") }.map { it.first })
        return JSONObject().put("name", name).put("description", desc)
            .put("input_schema", JSONObject().put("type", "object").put("properties", props).put("required", req))
    }
    private fun s(n: String, desc: String) = Triple(n, "string", desc)
    private fun i(n: String, desc: String) = Triple(n, "integer", desc)

    fun definitions(): List<JSONObject> = listOf(
        d("open_app", "Открыть установленное приложение по названию.", s("name", "Название приложения, как на экране")),
        d("open_url", "Открыть ссылку (http/https) в браузере.", s("url", "Адрес")),
        d("set_alarm", "Поставить будильник на время.", i("hour", "Час 0-23"), i("minute", "Минуты 0-59"), s("label", "(опц) Подпись")),
        d("set_timer", "Запустить таймер.", i("seconds", "Секунды"), s("label", "(опц) Подпись")),
        d("flashlight", "Включить или выключить фонарик.", Triple("on", "boolean", "true — включить")),
        d("set_volume", "Громкость мультимедиа в процентах.", i("percent", "0-100")),
        d("media", "Управление музыкой/видео.", s("action", "play_pause, next или previous")),
        d("call", "Открыть набор номера (звонок подтверждает пользователь).", s("number", "Номер")),
        d("send_sms", "Открыть написание SMS (отправку подтверждает пользователь).", s("number", "Номер"), s("text", "Текст")),
        d("open_settings", "Открыть настройки.", s("panel", "wifi, bluetooth, internet, volume, display, accessibility или main")),
        d("phone_control", "Управление экраном через специальные возможности.",
            s("action", "home, back, recents, notifications, quick_settings, screenshot, lock, click, scroll_down, scroll_up, swipe_left, swipe_right, swipe_up, swipe_down, type_text"),
            s("text", "(опц) Текст кнопки для click или текст для type_text")),
        d("read_screen", "Прочитать, что сейчас на экране телефона (Эрика на секунду свернётся, чтобы посмотреть)."),
        d("read_notifications", "Прочитать текущие уведомления."),
        d("read_clipboard", "Прочитать буфер обмена."),
        d("set_clipboard", "Положить текст в буфер обмена.", s("text", "Текст")),
        d("wait", "Подождать (например, пока откроется приложение).", i("seconds", "1-5")),
        d("save_note", "Запомнить в памяти ТОЛЬКО по просьбе пользователя.", s("kind", "profile или knowledge"), s("text", "Сжатая заметка до 300 символов")),
        d("read_notes", "Показать, что есть в памяти.", s("query", "(опц) О чём")),
        d("delete_note", "Забыть заметку по id.", i("id", "id заметки"))
    )

    suspend fun run(name: String, a: JSONObject, log: (String) -> Unit): String = try {
        when (name) {
            "open_app" -> openApp(a.getString("name"), log)
            "open_url" -> {
                val u = a.getString("url")
                if (!u.startsWith("http")) "Только http и https" else {
                    start(Intent(Intent.ACTION_VIEW, Uri.parse(u))); log("🌐 Открываю $u"); "ok"
                }
            }
            "set_alarm" -> {
                val h = a.getInt("hour"); val m = a.getInt("minute")
                start(Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, h)
                    .putExtra(AlarmClock.EXTRA_MINUTES, m)
                    .putExtra(AlarmClock.EXTRA_MESSAGE, a.optString("label", "Эрика"))
                    .putExtra(AlarmClock.EXTRA_SKIP_UI, true))
                log("⏰ Будильник на %02d:%02d".format(h, m)); "ok"
            }
            "set_timer" -> {
                val sec = a.getInt("seconds")
                start(Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, sec)
                    .putExtra(AlarmClock.EXTRA_MESSAGE, a.optString("label", "Эрика"))
                    .putExtra(AlarmClock.EXTRA_SKIP_UI, true))
                log("⏱ Таймер на $sec с"); "ok"
            }
            "flashlight" -> {
                val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
                val id = cm.cameraIdList.first { cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
                val on = a.getBoolean("on"); cm.setTorchMode(id, on)
                log(if (on) "🔦 Фонарик включён" else "🔦 Фонарик выключен"); "ok"
            }
            "set_volume" -> {
                val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
                val p = a.getInt("percent").coerceIn(0, 100)
                am.setStreamVolume(AudioManager.STREAM_MUSIC, am.getStreamMaxVolume(AudioManager.STREAM_MUSIC) * p / 100, 0)
                log("🔊 Громкость $p%"); "ok"
            }
            "media" -> {
                val code = when (a.getString("action")) {
                    "next" -> KeyEvent.KEYCODE_MEDIA_NEXT
                    "previous" -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
                    else -> KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE
                }
                val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
                am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
                am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
                log("🎵 ${a.getString("action")}"); "ok"
            }
            "call" -> { start(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(a.getString("number"))))); log("📞 Набираю"); "Открыла набор номера, нужно нажать вызов." }
            "send_sms" -> {
                start(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(a.getString("number")))).putExtra("sms_body", a.getString("text")))
                log("💬 Готовлю SMS"); "Открыла SMS, нужно нажать отправить."
            }
            "open_settings" -> { openSettings(a.getString("panel")); log("⚙ Настройки"); "ok" }
            "phone_control" -> {
                val act = a.getString("action")
                val r = PhoneControlService.perform(act, a.optString("text", ""))
                log("👆 $act" + (if (a.optString("text", "").isNotBlank()) " «${a.optString("text")}»" else "")); r
            }
            "read_screen" -> readScreen(log)
            "read_notifications" -> { log("🔔 Читаю уведомления"); NotifService.read() }
            "read_clipboard" -> {
                val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                log("📋 Читаю буфер")
                cm.primaryClip?.getItemAt(0)?.coerceToText(ctx)?.toString()?.take(3000) ?: "Буфер пуст (или Android не даёт читать из фона)."
            }
            "set_clipboard" -> {
                val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("Эрика", a.getString("text"))); log("📋 Скопировала"); "ok"
            }
            "wait" -> { delay(a.getInt("seconds").coerceIn(1, 5) * 1000L); "ok" }
            "save_note" -> {
                val (n, isNew) = store.add(a.optString("kind", "knowledge"), a.getString("text"))
                if (isNew) { log("🧠 Запомнила: " + n.text.take(80)); "Сохранено (id ${n.id})" } else "Такое уже есть в памяти."
            }
            "read_notes" -> {
                val q = a.optString("query", "")
                val list = if (q.isBlank()) store.all().takeLast(30) else store.all().filter { n -> q.lowercase().split(" ").any { w -> w.length > 2 && n.text.lowercase().contains(w) } }.takeLast(30)
                if (list.isEmpty()) "Память пуста." else list.joinToString("\n") { "[${it.id}] (${it.kind}) ${it.text}" }
            }
            "delete_note" -> if (store.delete(a.getLong("id"))) { log("🗑 Забыла заметку"); "Удалено" } else "Не нашла такую заметку"
            else -> "Неизвестный инструмент"
        }
    } catch (e: kotlinx.coroutines.CancellationException) { throw e
    } catch (e: Exception) { "Ошибка: ${e.message}" }

    private fun openApp(name: String, log: (String) -> Unit): String {
        val pm = ctx.packageManager
        val q = name.lowercase().trim()
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        val m = apps.firstOrNull { it.loadLabel(pm).toString().lowercase() == q }
            ?: apps.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(q) }
            ?: return "Не нашла приложение «$name»."
        val intent = pm.getLaunchIntentForPackage(m.activityInfo.packageName) ?: return "Не получилось запустить."
        start(intent)
        log("📱 Открываю " + m.loadLabel(pm))
        return "Открыла " + m.loadLabel(pm)
    }

    private fun openSettings(panel: String) {
        val i = when (panel) {
            "wifi" -> Intent(Settings.ACTION_WIFI_SETTINGS)
            "bluetooth" -> Intent(Settings.ACTION_BLUETOOTH_SETTINGS)
            "internet" -> if (Build.VERSION.SDK_INT >= 29) Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY) else Intent(Settings.ACTION_WIFI_SETTINGS)
            "volume" -> if (Build.VERSION.SDK_INT >= 29) Intent(Settings.Panel.ACTION_VOLUME) else Intent(Settings.ACTION_SOUND_SETTINGS)
            "display" -> Intent(Settings.ACTION_DISPLAY_SETTINGS)
            "accessibility" -> Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
            else -> Intent(Settings.ACTION_SETTINGS)
        }
        start(i)
    }

    private suspend fun readScreen(log: (String) -> Unit): String {
        val svc = PhoneControlService.instance
            ?: return "Служба управления экраном не включена. Включи её в настройках Эрики."
        log("👀 Смотрю на экран")
        val act = MainActivity.current?.get()
        val own = act != null && act.hasWindowFocus()
        if (own) { act!!.moveTaskToBack(true); delay(900) }
        val text = svc.readScreen()
        if (own) svc.bringAppToFront()
        return text
    }
}
