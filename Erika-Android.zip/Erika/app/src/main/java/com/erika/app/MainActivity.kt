package com.erika.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import java.lang.ref.WeakReference

private val BG = Color(0xFF0E1018)
private val VIOLET = Color(0xFF8E8CFF)
private val PALE = Color(0xF0EEEBFF)
private val INK = Color(0xFF23244A)
private val MUTED = Color(0xFF9AA0C8)

class MainActivity : ComponentActivity() {
    companion object { var current: WeakReference<MainActivity>? = null }

    private val vm: MainVM by viewModels()
    private val micPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) vm.toggle() else Toast.makeText(this, "Без микрофона я тебя не услышу", Toast.LENGTH_LONG).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        current = WeakReference(this)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = VIOLET)) {
                Surface(Modifier.fillMaxSize(), color = BG) { Root(vm) { onMic() } }
            }
        }
    }

    private fun onMic() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) vm.toggle()
        else micPerm.launch(Manifest.permission.RECORD_AUDIO)
    }

    override fun onDestroy() {
        if (current?.get() === this) current = null
        super.onDestroy()
    }
}

enum class Screen { MAIN, CHAT, NOTES, SETTINGS }

@Composable
fun Root(vm: MainVM, onMic: () -> Unit) {
    var screen by remember { mutableStateOf(if (vm.store.apiKey.isBlank()) Screen.SETTINGS else Screen.MAIN) }
    BackHandler(screen != Screen.MAIN) { screen = Screen.MAIN }
    when (screen) {
        Screen.MAIN -> MainScreen(vm, onMic) { screen = it }
        Screen.CHAT -> ChatScreen(vm) { screen = Screen.MAIN }
        Screen.NOTES -> NotesScreen(vm) { screen = Screen.MAIN }
        Screen.SETTINGS -> SettingsScreen(vm) { screen = Screen.MAIN }
    }
}

@Composable
private fun RoundBtn(label: String, onClick: () -> Unit) {
    Box(
        Modifier.size(44.dp).clip(CircleShape).background(Color(0x332A2D55)).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Text(label, fontSize = 20.sp) }
}

private fun label(vm: MainVM) = when (vm.status) {
    Status.LISTENING -> "Слушаю…"
    Status.THINKING -> "Думаю…"
    Status.SPEAKING -> "Говорю — нажми, чтобы перебить"
    Status.IDLE -> "Нажми на кнопку и говори"
}

@Composable
fun MainScreen(vm: MainVM, onMic: () -> Unit, nav: (Screen) -> Unit) {
    var typing by remember { mutableStateOf(false) }
    var text by remember { mutableStateOf("") }
    Box(Modifier.fillMaxSize()) {
        ErikaStage(vm.status, Modifier.fillMaxSize())
        Row(Modifier.align(Alignment.TopEnd).padding(8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            RoundBtn("💬") { nav(Screen.CHAT) }
            RoundBtn("🧠") { nav(Screen.NOTES) }
            RoundBtn("⚙") { nav(Screen.SETTINGS) }
        }
        Box(Modifier.align(Alignment.TopCenter).padding(top = 60.dp, start = 18.dp, end = 18.dp)) {
            SpeechBubble(vm.bubble, vm.status == Status.THINKING)
        }
        Column(
            Modifier.align(Alignment.BottomCenter).padding(start = 16.dp, end = 16.dp, bottom = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            if (vm.partial.isNotEmpty())
                Text(vm.partial, color = Color(0xFFCFD2FF), fontSize = 15.sp, fontStyle = FontStyle.Italic, textAlign = TextAlign.Center, maxLines = 2)
            else Text(label(vm), color = MUTED, fontSize = 13.sp)
            if (typing) {
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(text, { text = it }, Modifier.weight(1f), singleLine = true, placeholder = { Text("Напиши Эрике…") })
                    Spacer(Modifier.width(8.dp))
                    Button(onClick = { vm.send(text); text = "" }) { Text("➤") }
                }
            }
            Spacer(Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                RoundBtn("⌨") { typing = !typing }
                Spacer(Modifier.width(24.dp))
                MicButton(vm.status, onMic)
                Spacer(Modifier.width(24.dp))
                Spacer(Modifier.size(44.dp))
            }
        }
    }
}

@Composable
fun SpeechBubble(text: String?, thinking: Boolean) {
    val last = remember { object { var v = "" } }
    if (text != null) last.v = text
    AnimatedVisibility(
        visible = text != null || thinking,
        enter = fadeIn(tween(220)) + scaleIn(tween(220), initialScale = 0.85f, transformOrigin = TransformOrigin(0.5f, 1f)),
        exit = fadeOut(tween(350))
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                Modifier.clip(RoundedCornerShape(22.dp)).background(PALE)
                    .border(1.5.dp, VIOLET, RoundedCornerShape(22.dp))
                    .padding(horizontal = 18.dp, vertical = 12.dp)
            ) {
                if (text == null && thinking) Dots()
                else Text(text ?: last.v, color = INK, fontSize = 17.sp, lineHeight = 23.sp, textAlign = TextAlign.Center)
            }
            Canvas(Modifier.size(width = 22.dp, height = 12.dp)) {
                val p = Path().apply { moveTo(0f, 0f); lineTo(size.width, 0f); lineTo(size.width / 2f, size.height); close() }
                drawPath(p, PALE)
            }
        }
    }
}

@Composable
private fun Dots() {
    val a by rememberInfiniteTransition(label = "dots").animateFloat(
        0.25f, 1f, infiniteRepeatable(tween(700), RepeatMode.Reverse), label = "a"
    )
    Text("●  ●  ●", color = VIOLET.copy(alpha = a), fontSize = 14.sp)
}

@Composable
fun MicButton(status: Status, onClick: () -> Unit) {
    val pulse = rememberInfiniteTransition(label = "mic").animateFloat(
        1f, 1.14f, infiniteRepeatable(tween(800), RepeatMode.Reverse), label = "p"
    )
    val color = when (status) {
        Status.LISTENING -> Color(0xFFFF6B8A)
        Status.THINKING -> Color(0xFFFFC857)
        Status.SPEAKING -> Color(0xFF6EE7B7)
        Status.IDLE -> Color(0xFF7C83FF)
    }
    Box(
        Modifier.size(84.dp)
            .graphicsLayer { val s = if (status == Status.LISTENING) pulse.value else 1f; scaleX = s; scaleY = s }
            .clip(CircleShape).background(color).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(
            when (status) { Status.LISTENING -> "■"; Status.THINKING -> "…"; Status.SPEAKING -> "🔊"; Status.IDLE -> "🎙" },
            fontSize = 30.sp, color = BG
        )
    }
}

@Composable
private fun TopBar(title: String, onBack: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        TextButton(onClick = onBack) { Text("←", fontSize = 22.sp) }
        Text(title, fontSize = 20.sp, color = Color.White)
    }
}

@Composable
fun ChatScreen(vm: MainVM, onBack: () -> Unit) {
    val state = rememberLazyListState()
    LaunchedEffect(vm.chat.size) { if (vm.chat.isNotEmpty()) state.scrollToItem(vm.chat.size - 1) }
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.weight(1f)) { TopBar("Разговор", onBack) }
            TextButton(onClick = { vm.clearChat() }) { Text("Очистить") }
        }
        LazyColumn(Modifier.fillMaxSize(), state = state, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(vm.chat) { m ->
                when (m.who) {
                    2 -> Text(m.text, color = MUTED, fontSize = 13.sp, fontStyle = FontStyle.Italic, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
                    else -> Row(Modifier.fillMaxWidth(), horizontalArrangement = if (m.who == 0) Arrangement.End else Arrangement.Start) {
                        Box(
                            Modifier.widthIn(max = 300.dp).clip(RoundedCornerShape(18.dp))
                                .background(if (m.who == 0) Color(0xFF3B3F8F) else Color(0xFFE7E4FF))
                                .padding(horizontal = 14.dp, vertical = 9.dp)
                        ) { Text(m.text, color = if (m.who == 0) Color.White else INK, fontSize = 16.sp) }
                    }
                }
            }
        }
    }
}

@Composable
fun NotesScreen(vm: MainVM, onBack: () -> Unit) {
    var text by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        TopBar("Память Эрики", onBack)
        Text("Она запоминает только то, что ты просишь: «запомни…», «выучи…».", color = MUTED, fontSize = 13.sp)
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(text, { text = it }, Modifier.weight(1f), singleLine = true, placeholder = { Text("Добавить факт о тебе…") })
            Spacer(Modifier.width(8.dp))
            Button(onClick = { vm.addNote(text); text = "" }) { Text("+") }
        }
        Spacer(Modifier.height(8.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(vm.notes.reversed(), key = { it.id }) { n ->
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Color(0xFF1A1C33)).padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(if (n.kind == "profile") "о тебе" else "знание", color = VIOLET, fontSize = 11.sp)
                        Text(n.text, color = Color.White, fontSize = 15.sp)
                    }
                    TextButton(onClick = { vm.deleteNote(n.id) }) { Text("✕") }
                }
            }
        }
    }
}

@Composable
fun SettingsScreen(vm: MainVM, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val owner = LocalLifecycleOwner.current
    var refresh by remember { mutableIntStateOf(0) }
    DisposableEffect(owner) {
        val ob = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) refresh++ }
        owner.lifecycle.addObserver(ob)
        onDispose { owner.lifecycle.removeObserver(ob) }
    }
    val a11yOn = remember(refresh) { PhoneControlService.instance != null }
    val notifOn = remember(refresh) { NotifService.instance != null }

    var key by remember { mutableStateOf(vm.store.apiKey) }
    var model by remember { mutableStateOf(vm.store.model) }
    var search by remember { mutableStateOf(vm.store.searchEnabled) }
    var pitch by remember { mutableFloatStateOf(vm.store.pitch) }
    var rate by remember { mutableFloatStateOf(vm.store.rate) }

    Column(Modifier.fillMaxSize().padding(14.dp).verticalScroll(rememberScrollState())) {
        TopBar("Настройки", onBack)
        OutlinedTextField(key, { key = it; vm.store.apiKey = it }, Modifier.fillMaxWidth(), singleLine = true,
            label = { Text("API-ключ Anthropic") }, visualTransformation = PasswordVisualTransformation())
        Spacer(Modifier.height(14.dp))
        Text("Модель", color = MUTED, fontSize = 13.sp)
        listOf(
            "Haiku 5.5 — быстро и дёшево" to "claude-haiku-5-5",
            "Sonnet 5.5 — умная и быстрая" to "claude-sonnet-5-5",
            "Opus 5.5 — самая умная" to "claude-opus-5-5"
        ).forEach { (title, id) ->
            val sel = model == id
            if (sel) Button({ }, Modifier.fillMaxWidth()) { Text(title) }
            else OutlinedButton({ model = id; vm.store.model = id }, Modifier.fillMaxWidth()) { Text(title) }
        }
        Row(Modifier.fillMaxWidth().padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Поиск в интернете (только по твоей просьбе)", Modifier.weight(1f), color = Color.White)
            Switch(search, { search = it; vm.store.searchEnabled = it })
        }
        Spacer(Modifier.height(10.dp))
        Text("Голос: высота %.2f".format(pitch), color = MUTED, fontSize = 13.sp)
        Slider(pitch, { pitch = it; vm.store.pitch = it }, valueRange = 0.8f..1.6f)
        Text("Голос: скорость %.2f".format(rate), color = MUTED, fontSize = 13.sp)
        Slider(rate, { rate = it; vm.store.rate = it }, valueRange = 0.7f..1.4f)
        OutlinedButton({
            val vs = vm.voice.voices()
            if (vs.isEmpty()) Toast.makeText(ctx, "Голоса ещё загружаются или не установлены", Toast.LENGTH_LONG).show()
            else {
                val next = vs[(vs.indexOf(vm.store.voiceName) + 1).mod(vs.size)]
                vm.store.voiceName = next
                vm.previewVoice()
                Toast.makeText(ctx, next, Toast.LENGTH_SHORT).show()
            }
        }, Modifier.fillMaxWidth()) { Text("Сменить голос и послушать") }

        Spacer(Modifier.height(18.dp))
        Text("Доступ к телефону (всё работает только по твоей команде)", color = Color.White, fontSize = 15.sp)
        Spacer(Modifier.height(6.dp))
        OutlinedButton({ ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }, Modifier.fillMaxWidth()) {
            Text(if (a11yOn) "✅ Управление экраном включено" else "Включить управление экраном")
        }
        OutlinedButton({ ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }, Modifier.fillMaxWidth()) {
            Text(if (notifOn) "✅ Чтение уведомлений включено" else "Включить чтение уведомлений")
        }
        Spacer(Modifier.height(14.dp))
        Button(onBack, Modifier.fillMaxWidth()) { Text("Готово") }
    }
}
