package com.erika.app

import android.app.Application
import android.os.Handler
import android.os.Looper
import android.speech.SpeechRecognizer
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

enum class Status { IDLE, LISTENING, THINKING, SPEAKING }
data class Msg(val who: Int, val text: String) // 0 — ты, 1 — Эрика, 2 — действие

class MainVM(app: Application) : AndroidViewModel(app), Voice.Callback {
    val store = Store(app)
    private val agent = Agent(store, DeviceTools(app, store))
    val voice = Voice(app, store, this)
    private val main = Handler(Looper.getMainLooper())

    var status by mutableStateOf(Status.IDLE); private set
    var bubble by mutableStateOf<String?>(null); private set
    var partial by mutableStateOf(""); private set
    var chat by mutableStateOf(listOf<Msg>()); private set
    var conversation by mutableStateOf(false); private set
    var notes by mutableStateOf(store.all()); private set

    private var chunks = listOf<String>()
    private var job: Job? = null
    private var hideJob: Job? = null
    private val stopWords = setOf("стоп", "хватит", "пока", "отбой", "всё", "все")

    init { agent.onAction = { t -> main.post { chat = (chat + Msg(2, t)).takeLast(200); notes = store.all() } } }

    fun refreshNotes() { notes = store.all() }
    fun deleteNote(id: Long) { store.delete(id); refreshNotes() }
    fun addNote(text: String) { if (text.isNotBlank()) { store.add("profile", text); refreshNotes() } }
    fun clearChat() { chat = emptyList(); agent.reset() }

    /** Кнопка с микрофоном. */
    fun toggle() {
        when {
            conversation && status == Status.SPEAKING -> { voice.stopSpeaking(); hideJob?.cancel(); bubble = null; startListen() }
            conversation -> stop()
            else -> { conversation = true; startListen() }
        }
    }

    fun stop() {
        conversation = false
        job?.cancel(); hideJob?.cancel()
        voice.stopAll()
        status = Status.IDLE; partial = ""; bubble = null
    }

    private fun startListen() {
        if (!SpeechRecognizer.isRecognitionAvailable(getApplication())) {
            chat += Msg(2, "Распознавание речи недоступно на этом телефоне"); stop(); return
        }
        status = Status.LISTENING
        voice.listen()
    }

    override fun onPartial(t: String) { partial = t }
    override fun onFinal(t: String) { partial = ""; send(t) }

    override fun onListenError(code: Int) {
        if (!conversation || status != Status.LISTENING) return
        if (code == SpeechRecognizer.ERROR_NO_MATCH || code == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) {
            main.postDelayed({ if (conversation && status == Status.LISTENING) startListen() }, 400)
        } else {
            chat += Msg(2, "Не слышу микрофон (код $code)"); stop()
        }
    }

    /** Текст от тебя: голосом или с клавиатуры. */
    fun send(text: String) {
        val t = text.trim()
        if (t.isEmpty()) return
        voice.stopAll(); hideJob?.cancel(); partial = ""
        chat += Msg(0, t)
        if (t.lowercase().trim('.', '!', ' ', ',') in stopWords) { stop(); return }
        status = Status.THINKING; bubble = null
        job?.cancel()
        job = viewModelScope.launch {
            val reply = agent.ask(t)
            refreshNotes()
            say(reply)
        }
    }

    private fun say(reply: String) {
        chat += Msg(1, reply)
        val ch = chunk(reply)
        if (ch.isEmpty()) { onSpeakDone(); return }
        chunks = ch; status = Status.SPEAKING; bubble = ch[0]
        if (voice.ready) voice.speak(ch)
        else job = viewModelScope.launch {
            for (c in ch) { bubble = c; delay(900L + c.length * 55L) }
            onSpeakDone()
        }
    }

    override fun onChunk(i: Int) { if (i in chunks.indices) bubble = chunks[i] }

    override fun onSpeakDone() {
        hideJob?.cancel()
        hideJob = viewModelScope.launch { delay(2600); if (status != Status.SPEAKING) bubble = null }
        if (conversation) startListen() else status = Status.IDLE
    }

    fun previewVoice() { chunks = listOf("Привет! Вот так я теперь звучу."); bubble = chunks[0]; status = Status.SPEAKING; voice.speak(chunks) }

    private fun chunk(text: String): List<String> {
        val clean = text.replace(Regex("[*_#`>]+"), "").replace(Regex("\\s+"), " ").trim()
        if (clean.isEmpty()) return emptyList()
        val sents = clean.split(Regex("(?<=[.!?…])\\s+"))
        val out = mutableListOf<String>()
        var cur = StringBuilder()
        for (s in sents) {
            if (cur.isNotEmpty() && cur.length + s.length > 150) { out += cur.toString().trim(); cur = StringBuilder() }
            cur.append(s).append(' ')
        }
        if (cur.isNotBlank()) out += cur.toString().trim()
        return out.flatMap { if (it.length > 230) it.chunked(200) else listOf(it) }
    }

    override fun onCleared() { voice.shutdown() }
}
