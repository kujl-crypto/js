package com.erika.app

import android.app.Notification
import android.service.notification.NotificationListenerService

/** Ничего не хранит. Уведомления читаются только в момент, когда ты просишь Эрику их прочитать. */
class NotifService : NotificationListenerService() {
    companion object {
        @Volatile var instance: NotifService? = null
        fun read(): String {
            val s = instance ?: return "Доступ к уведомлениям не включён. Включи его в настройках Эрики."
            val list = try { s.activeNotifications } catch (e: Exception) { return "Не удалось прочитать уведомления." }
            val pm = s.packageManager
            val lines = list.filter { !it.isOngoing && it.packageName != s.packageName }.take(25).mapNotNull { sbn ->
                val ex = sbn.notification.extras
                val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString()
                val text = (ex.getCharSequence(Notification.EXTRA_BIG_TEXT) ?: ex.getCharSequence(Notification.EXTRA_TEXT))?.toString()
                if (title.isNullOrBlank() && text.isNullOrBlank()) return@mapNotNull null
                val app = try { pm.getApplicationLabel(pm.getApplicationInfo(sbn.packageName, 0)).toString() } catch (e: Exception) { sbn.packageName }
                "$app: ${title ?: ""} — ${(text ?: "").take(200)}"
            }
            return if (lines.isEmpty()) "Уведомлений нет." else lines.joinToString("\n")
        }
    }
    override fun onListenerConnected() { instance = this }
    override fun onListenerDisconnected() { instance = null }
}
