package com.erika.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.os.Build
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/** Работает только когда Эрика вызывает действие по твоей просьбе. Сам по себе ничего не делает и не собирает. */
class PhoneControlService : AccessibilityService() {
    companion object {
        @Volatile var instance: PhoneControlService? = null
        private const val NEED = "Служба управления экраном не включена. Включи её в настройках Эрики."
        fun perform(action: String, text: String?): String = instance?.doAction(action, text) ?: NEED
    }

    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    private fun g(a: Int): String = if (performGlobalAction(a)) "ok" else "Не получилось"

    private fun doAction(a: String, text: String?): String = when (a) {
        "home" -> g(GLOBAL_ACTION_HOME)
        "back" -> g(GLOBAL_ACTION_BACK)
        "recents" -> g(GLOBAL_ACTION_RECENTS)
        "notifications" -> g(GLOBAL_ACTION_NOTIFICATIONS)
        "quick_settings" -> g(GLOBAL_ACTION_QUICK_SETTINGS)
        "screenshot" -> if (Build.VERSION.SDK_INT >= 28) g(GLOBAL_ACTION_TAKE_SCREENSHOT) else "Нужен Android 9+"
        "lock" -> if (Build.VERSION.SDK_INT >= 28) g(GLOBAL_ACTION_LOCK_SCREEN) else "Нужен Android 9+"
        "click" -> click(text)
        "scroll_down" -> scroll(true)
        "scroll_up" -> scroll(false)
        "swipe_left" -> swipe(0.8f, 0.5f, 0.2f, 0.5f)
        "swipe_right" -> swipe(0.2f, 0.5f, 0.8f, 0.5f)
        "swipe_up" -> swipe(0.5f, 0.75f, 0.5f, 0.25f)
        "swipe_down" -> swipe(0.5f, 0.25f, 0.5f, 0.75f)
        "type_text" -> typeText(text)
        else -> "Неизвестное действие"
    }

    private fun click(t: String?): String {
        if (t.isNullOrBlank()) return "Нужен текст кнопки"
        val root = rootInActiveWindow ?: return "Нет доступа к экрану"
        var n: AccessibilityNodeInfo? = root.findAccessibilityNodeInfosByText(t).firstOrNull()
            ?: return "Не нашла «$t» на экране"
        while (n != null && !n.isClickable) n = n.parent
        return if (n?.performAction(AccessibilityNodeInfo.ACTION_CLICK) == true) "ok" else "Не получилось нажать «$t»"
    }

    private fun findScrollable(n: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (n == null) return null
        if (n.isScrollable) return n
        for (i in 0 until n.childCount) findScrollable(n.getChild(i))?.let { return it }
        return null
    }

    private fun scroll(forward: Boolean): String {
        val sc = findScrollable(rootInActiveWindow) ?: return "Нечего листать"
        val act = if (forward) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        return if (sc.performAction(act)) "ok" else "Дальше листать некуда"
    }

    private fun swipe(x1: Float, y1: Float, x2: Float, y2: Float): String {
        val dm = resources.displayMetrics
        val p = Path().apply { moveTo(dm.widthPixels * x1, dm.heightPixels * y1); lineTo(dm.widthPixels * x2, dm.heightPixels * y2) }
        val ok = dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 350)).build(), null, null)
        return if (ok) "ok" else "Жест не выполнился"
    }

    private fun findEditable(n: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (n == null) return null
        if (n.isEditable) return n
        for (i in 0 until n.childCount) findEditable(n.getChild(i))?.let { return it }
        return null
    }

    private fun typeText(t: String?): String {
        if (t == null) return "Нужен текст"
        val root = rootInActiveWindow ?: return "Нет доступа к экрану"
        val f = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: findEditable(root) ?: return "Не вижу поля ввода"
        val args = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, t) }
        return if (f.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) "ok" else "Не получилось вписать"
    }

    fun readScreen(): String {
        val root = rootInActiveWindow ?: return "Не удалось увидеть экран."
        val sb = StringBuilder("Приложение: ${root.packageName}\n")
        fun walk(n: AccessibilityNodeInfo?, depth: Int) {
            if (n == null || sb.length > 3000 || depth > 25) return
            if (n.isVisibleToUser) {
                val t = (n.text ?: n.contentDescription)?.toString()?.trim()
                if (!t.isNullOrEmpty()) {
                    sb.append(if (n.isEditable) "[поле] " else if (n.isClickable) "[кнопка] " else "").append(t.take(160)).append('\n')
                }
            }
            for (i in 0 until n.childCount) walk(n.getChild(i), depth + 1)
        }
        walk(root, 0)
        return sb.toString().take(3200)
    }

    fun bringAppToFront() {
        packageManager.getLaunchIntentForPackage(packageName)?.let {
            it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
            try { startActivity(it) } catch (_: Exception) { }
        }
    }
}
