package com.erika.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** kind: "profile" — факты о тебе и предпочтения (всегда в контексте), "knowledge" — знания (подтягиваются по теме). */
data class Note(val id: Long, val kind: String, val text: String, val time: Long)

class Store(private val ctx: Context) {
    private val prefs = ctx.getSharedPreferences("erika", Context.MODE_PRIVATE)
    private val file get() = File(ctx.filesDir, "memory.json")
    private var cache: MutableList<Note>? = null

    var apiKey: String
        get() = prefs.getString("key", "") ?: ""
        set(v) = prefs.edit().putString("key", v.trim()).apply()
    var model: String
        get() = prefs.getString("model", "claude-sonnet-5-5") ?: "claude-sonnet-5-5"
        set(v) = prefs.edit().putString("model", v.trim()).apply()
    var searchEnabled: Boolean
        get() = prefs.getBoolean("search", true)
        set(v) = prefs.edit().putBoolean("search", v).apply()
    var pitch: Float
        get() = prefs.getFloat("pitch", 1.18f)
        set(v) = prefs.edit().putFloat("pitch", v).apply()
    var rate: Float
        get() = prefs.getFloat("rate", 1.02f)
        set(v) = prefs.edit().putFloat("rate", v).apply()
    var voiceName: String
        get() = prefs.getString("voice", "") ?: ""
        set(v) = prefs.edit().putString("voice", v).apply()

    // ---------- память ----------
    @Synchronized
    private fun load(): MutableList<Note> {
        cache?.let { return it }
        val list = mutableListOf<Note>()
        try {
            if (file.exists()) {
                val a = JSONArray(file.readText())
                for (i in 0 until a.length()) {
                    val o = a.getJSONObject(i)
                    list.add(Note(o.getLong("id"), o.optString("kind", "knowledge"), o.getString("text"), o.getLong("time")))
                }
            }
        } catch (_: Exception) { }
        cache = list
        return list
    }

    @Synchronized
    private fun save() {
        val a = JSONArray()
        load().forEach { a.put(JSONObject().put("id", it.id).put("kind", it.kind).put("text", it.text).put("time", it.time)) }
        file.writeText(a.toString())
    }

    @Synchronized fun all(): List<Note> = load().toList()

    @Synchronized
    fun add(kind: String, text: String): Pair<Note, Boolean> {
        val t = text.trim().take(400)
        val k = if (kind == "profile") "profile" else "knowledge"
        val tw = words(t)
        val list = load()
        val dup = list.firstOrNull { it.text.equals(t, true) || jaccard(words(it.text), tw) > 0.8f }
        if (dup != null) return dup to false
        var id = System.currentTimeMillis()
        while (list.any { it.id == id }) id++
        val n = Note(id, k, t, id)
        list.add(n)
        while (list.size > 300) {                       // экономия памяти: самые старые знания уходят первыми
            val old = list.firstOrNull { it.kind == "knowledge" } ?: list.first()
            list.remove(old)
        }
        save()
        return n to true
    }

    @Synchronized
    fun delete(id: Long): Boolean {
        val r = load().removeAll { it.id == id }
        if (r) save()
        return r
    }

    @Synchronized fun clearAll() { load().clear(); save() }

    fun profile(): List<Note> = all().filter { it.kind == "profile" }.takeLast(12)

    fun relevant(query: String, max: Int = 6): List<Note> {
        val qw = words(query)
        if (qw.isEmpty()) return emptyList()
        return all().filter { it.kind == "knowledge" }
            .map { it to words(it.text).count { w -> w in qw } }
            .filter { it.second > 0 }
            .sortedWith(compareByDescending<Pair<Note, Int>> { it.second }.thenByDescending { it.first.time })
            .take(max).map { it.first }
    }

    private fun words(s: String): Set<String> =
        s.lowercase().split(Regex("[^\\p{L}\\p{Nd}]+")).filter { it.length >= 3 }.map { it.take(5) }.toSet()

    private fun jaccard(a: Set<String>, b: Set<String>): Float {
        if (a.isEmpty() || b.isEmpty()) return 0f
        return a.intersect(b).size.toFloat() / a.union(b).size.toFloat()
    }
}
