package com.erika.app

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

class Voice(private val ctx: Context, private val store: Store, private val cb: Callback) {
    interface Callback {
        fun onPartial(t: String)
        fun onFinal(t: String)
        fun onListenError(code: Int)
        fun onChunk(i: Int)
        fun onSpeakDone()
    }

    private val main = Handler(Looper.getMainLooper())
    private var rec: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    @Volatile var ready = false
        private set
    @Volatile private var lastId = ""

    init {
        tts = TextToSpeech(ctx.applicationContext) { st ->
            if (st == TextToSpeech.SUCCESS) {
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(id: String?) {
                        val i = id?.removePrefix("c")?.toIntOrNull() ?: return
                        main.post { cb.onChunk(i) }
                    }
                    override fun onDone(id: String?) { if (id == lastId) main.post { cb.onSpeakDone() } }
                    @Deprecated("Deprecated in Java")
                    override fun onError(id: String?) { if (id == lastId) main.post { cb.onSpeakDone() } }
                })
                applyVoice()
                ready = true
            }
        }
    }

    fun voices(): List<String> =
        try { tts?.voices?.filter { it.locale.language == "ru" }?.map { it.name }?.sorted() ?: emptyList() } catch (e: Exception) { emptyList() }

    fun applyVoice() {
        val t = tts ?: return
        t.language = Locale("ru", "RU")
        try {
            val vs = t.voices?.filter { it.locale.language == "ru" } ?: emptyList()
            val pick = vs.firstOrNull { it.name == store.voiceName } ?: vs.firstOrNull { it.name.contains("female", true) }
            if (pick != null) t.voice = pick
        } catch (_: Exception) { }
        t.setPitch(store.pitch)
        t.setSpeechRate(store.rate)
    }

    fun speak(chunks: List<String>) {
        val t = tts ?: return
        applyVoice()
        chunks.forEachIndexed { i, c ->
            t.speak(c, if (i == 0) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD, null, "c$i")
        }
        lastId = "c${chunks.size - 1}"
    }

    fun stopSpeaking() { lastId = ""; tts?.stop() }

    fun listen() {
        stopSpeaking()
        rec?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(ctx)
        rec = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(t: Int, p: Bundle?) {}
            override fun onError(e: Int) { cb.onListenError(e) }
            override fun onResults(b: Bundle?) {
                val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (t.isNullOrBlank()) cb.onListenError(SpeechRecognizer.ERROR_NO_MATCH) else cb.onFinal(t)
            }
            override fun onPartialResults(b: Bundle?) {
                b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { cb.onPartial(it) }
            }
        })
        r.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            .putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1500L))
    }

    fun stopListening() { rec?.cancel() }

    fun stopAll() { stopListening(); stopSpeaking() }

    fun shutdown() { rec?.destroy(); tts?.shutdown() }
}
